const openButton = document.getElementById("trigger-modal");
const closeButton = document.getElementById("closeButton");
const form = document.getElementById("ct-form");
const topSection = document.getElementById("topSection");
const midSection = document.getElementById("midSection");
const botSection = document.getElementById("botSection");
const pageDownButton = document.getElementById("scrollDownButton");
const inputFields = document.getElementsByClassName("form-input");
const submitButton = document.getElementById("form-submit");
const prevButton = document.getElementById("prevButton");
const nextButton = document.getElementById("nextButton");

openButton.addEventListener("click",openFormClick);
openButton.addEventListener("keydown", function(event){
  if(event.keyCode === 13){
    openButton.click();
  }
});
function openFormClick(){
  form.style.opacity = "1";
  form.style.visibility = "visible";
  topSection.style.filter = "blur(20px)";
  midSection.style.filter = "blur(20px)";
  botSection.style.filter = "blur(20px)";
  openButton.removeEventListener("click",openFormClick);
  pageDownButton.removeEventListener("click",pageDown);
}

closeButton.addEventListener("click",closeFormClick);
closeButton.addEventListener("keydown", function(event){
  if(event.keyCode === 13){
    closeButton.click();
  }
});
function closeFormClick(){
  form.style.opacity="0";
  form.style.visibility = "hidden";
  topSection.style.filter = "blur(0px)";
  midSection.style.filter = "blur(0px)";
  botSection.style.filter = "blur(0px)";
  openButton.addEventListener("click",openFormClick);
  pageDownButton.addEventListener("click",pageDown);
  let i=0;
  for(i=0;i<inputFields.length;i++){
    inputFields[i].value = '';
  }
};

pageDownButton.addEventListener("click",pageDown);
pageDownButton.addEventListener("keydown", function(event){
  if(event.keyCode === 13){
    pageDownButton.click();
  }
});
function pageDown(){
  document.getElementById('midSection').scrollIntoView();
}

submitButton.addEventListener("click",closeFormClick);
submitButton.addEventListener("keydown", function(event){
  if(event.keyCode === 13){
    submitButton.click();
  }
});

let storyIndex = 1;

showStory(storyIndex);

function plusStory(n) {
  showStory(storyIndex += n);
}
function showStory(n) {
  let i;
  let story = document.getElementsByClassName("story");
  if (n > story.length) {
    storyIndex = 1;
    }

  if (n < 1) {
    storyIndex = story.length;
    }
  for (i = 0; i < story.length; i++) {
    story[i].style.display = "none";
  
  story[storyIndex-1].style.display = "block";
  }
}

prevButton.addEventListener("keydown", function(event){
  if(event.keyCode === 13){
    prevButton.click();
  }
});

nextButton.addEventListener("keydown", function(event){
  if(event.keyCode === 13){
    nextButton.click();
  }
});
